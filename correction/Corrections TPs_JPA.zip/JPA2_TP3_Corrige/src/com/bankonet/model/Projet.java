package com.bankonet.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Projet {
	
 @Id
 @GeneratedValue
  private int id;
  private String nom;
	
  transient String attributNonpersiste;
// un attribut marqu� transient ne sera pas persist�
  
  
  @ManyToMany(mappedBy="projets")
  private List<Employe> employes  = new ArrayList<Employe>();;
  
  @OneToMany(cascade=CascadeType.PERSIST, mappedBy="projet")
  private List<Participation> participations =
    new ArrayList<Participation>();
  
  
  public Projet() {  
  }
  
  
  
  public Projet(String nom) {
	this.nom = nom;
}



public List<Employe> getEmployes() {
	    return employes;
	  }
  
  
  public int getId() {
    return id;
  }

  public String getNom() {
    return nom;
  }

  public void setNom(String nom) {
    this.nom = nom;
  }
  
  /**
   * Ajoute un employ� dans ce projet.
   *
   * @param employe
   * @param fonction
   */
  public void ajouterParticipant(Employe employe, String fonction) {
    Participation participation = 
      new Participation(employe, this, fonction);
    // Pourrait �tre fait dans le code du constructeur de Participation
    employe.getParticipations().add(participation);
    this.participations.add(participation);
  }

  public List<Participation> getParticipations() {
    return participations;
  }

  public void setParticipations(List<Participation> participations) {
    this.participations = participations;
  }
}

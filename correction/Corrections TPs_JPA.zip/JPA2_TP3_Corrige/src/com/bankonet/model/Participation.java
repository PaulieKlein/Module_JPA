package com.bankonet.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * Participation d'un employ� � un projet.
 * Solution avec un identificateur ajout� (id).
 * Une autre solution, sans cet identificateur, qui utilise
 * les cl�s compos�es de JPA 2.0 est donn�e par ailleurs.
 */
@Entity
@Table(name="PARTICIPATION2",
  // parce qu'un employ� ne peut avoir qu'une seule fonction dans un projet
  // il faut ajouter une contrainte d'unicit� � la table.
  uniqueConstraints=@UniqueConstraint(columnNames={"EMPLOYE_ID", "PROJET_ID"}))
public class Participation {
  @Id @GeneratedValue
  private int id;
  @ManyToOne
  private Employe employe;
  @ManyToOne
  private Projet projet;
  private String fonction;
	
  // Requis par JPA
  public Participation() {
  }

  public Participation(Employe employe, Projet projet, String fonction) {
    this.employe = employe;
    this.projet = projet;
    this.fonction = fonction;
  }

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }

  public Employe getEmploye() {
    return employe;
  }

  public void setEmploye(Employe employe) {
    this.employe = employe;
  }

  public String getFonction() {
    return fonction;
  }

  public void setFonction(String fonction) {
    this.fonction = fonction;
  }

  public Projet getProjet() {
    return projet;
  }

  public void setProjet(Projet projet) {
    this.projet = projet;
  }
}

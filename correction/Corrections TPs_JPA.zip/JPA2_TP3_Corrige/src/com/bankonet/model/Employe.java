package com.bankonet.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;

/** 
 * Un employ� de l'entreprise.
 */
@Entity
@DiscriminatorValue("E")
@NamedQuery(
		  name = "findNomsEmployes",
		  query = "select e.nom from Employe as e where upper(e.departement.nom) = :nomDept"
		)
public class Employe extends Personne {
  private BigDecimal salaire;
  @ManyToOne
  private Employe superieur;
  @ManyToOne
  private Departement departement;
	
  @ManyToMany
  @JoinTable(
	      name="EMP_PROJ",
	      joinColumns={@JoinColumn(name="EMP_ID", referencedColumnName="ID")},
	      inverseJoinColumns={@JoinColumn(name="PROJ_ID", referencedColumnName="ID")})
  private List<Projet> projets = new ArrayList<Projet>();
  // penser toujours � initialiser une collection � vide ! 
  
  @OneToMany(cascade=CascadeType.PERSIST, mappedBy="employe")
  private List<Participation> participations = new ArrayList<Participation>();
	
  
  
  public Employe() {
  }
	
  public Employe(String nom) {
    super(nom);
  }

  /**
   * M�thodes utilitaires souvent employ�es pour les associations
   * bidirectionnelles pour �viter d'oublier de mettre � jour
   * un des bouts de l'assocation.
   * @param p
   */
  public void addProjet(Projet p) {
    this.projets.add(p);
    p.getEmployes().add(this);
  }
  
  public void removeProjet(Projet p) {
	  p.getEmployes().remove(this);
      this.projets.remove(p);
	  }
  
  public List<Projet> getProjets() {
	return projets;
}

  // a ne pas utiliser : on affecte des projets � un employ� par la methode "addEmploye" de la classe Projet
public void setProjets(List<Projet> projets) {
	this.projets = projets;
}

public Employe(String nom, Departement departement, Employe superieur) {
    super(nom);
    departement.addEmploye(this);
    this.superieur = superieur;
  }

  public BigDecimal getSalaire() {
    return salaire;
  }

  public void setSalaire(BigDecimal salaire) {
    this.salaire = salaire;
  }

  public Employe getSuperieur() {
    return superieur;
  }

  public void setSuperieur(Employe employe) {
    this.superieur = employe;
  }

  public Departement getDepartement() {
    return departement;
  }

  public void setDepartement(Departement departement) {
    this.departement = departement;
  }
  
  public List<Participation> getParticipations() {
	    return participations ;
	 }

	  public void setParticipations(List<Participation> participations) {
	    this.participations = participations;
	  }
}

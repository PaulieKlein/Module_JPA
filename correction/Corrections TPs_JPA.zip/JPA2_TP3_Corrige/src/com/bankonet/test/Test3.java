package com.bankonet.test;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.bankonet.model.*;

public class Test3 {

  public static void main(String[] args) {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("Employes");
    EntityManager em = emf.createEntityManager();
    // R�cup�re des entit�s
    String texteQuery1 =
      "select e from Employe as e where upper(e.departement.nom) = :nomDept";
    Query query1 = em.createQuery(texteQuery1);
    query1.setParameter("nomDept", "Direction");
    List<Employe> listeEmployes = (List<Employe>)query1.getResultList();
    for (Employe employe : listeEmployes) {
      System.out.println("Employ�s du d�partement Direction = "+employe.getNom());
    }
    // Modification "en volume" de tous les salaires
    EntityTransaction tx = em.getTransaction();
    tx.begin();
    String texteUpdate =
      "update Employe e set e.salaire = 2200";
    Query updateQuery = em.createQuery(texteUpdate);
    int n = updateQuery.executeUpdate();
    tx.commit();
    System.out.println("Nombre de salaires modifi�s = " + n);
    // V�rifie qu'une requ�te en volume ne modifie pas les entit�s en m�moire
    Employe emp = listeEmployes.get(0);
    System.out.println("Salaire de " + emp.getNom() + " avant refresh = " + emp.getSalaire());
    // Synchronisation avec la BD
    em.refresh(emp);
    System.out.println("Salaire de " + emp.getNom() + " apr�s refresh = " + emp.getSalaire());
    // Requ�te avec 2 expressions "valeurs" (pas entit�s enti�res) dans le select
    String texteQuery2 = "select e.nom, e.salaire from Employe as e where upper(e.departement.nom) = :nomDept";
    Query query2 = em.createQuery(texteQuery2);
    query2.setParameter("nomDept", "Direction");
    List<Object[]> liste = (List<Object[]>)query2.getResultList();
    for (Object[] info : liste) {
      System.out.println("R�cup�ration nom et salaire :" +info[0] + " gagne " + info[1]);
    }
    // Utilisation d'une requ�te nomm�e
    Query query3 = em.createNamedQuery("findNomsEmployes");
    query3.setParameter("nomDept", "DIRECTION");
    List<String> listeNoms = (List<String>)query3.getResultList();
    for (String nom : listeNoms) {
      System.out.println("Utilisation d'une requete nomm�e :"+nom);
    }
    // Augmente de 5% les salaires des employ�s r�cup�r�s au d�but
    tx = em.getTransaction();
    tx.begin();
    System.out.println("Salaires avant l'augmentation :");
    listeEmployes = (List<Employe>)query1.getResultList();
    for (Employe employe : listeEmployes) {
      System.out.println(employe.getNom() + " gagne " + employe.getSalaire());
    }
    for (Employe employe : listeEmployes) {
      employe.setSalaire(employe.getSalaire().multiply(new BigDecimal(1.05)));
    }
    tx.commit();
    System.out.println("Salaires dans la BD apr�s l'augmentation :");
    listeEmployes = (List<Employe>)query1.getResultList();
    for (Employe employe : listeEmployes) {
      System.out.println(employe.getNom() + " gagne " + employe.getSalaire());
    }
    // Laiss� en exercice : g�rer les exceptions et fermer dans un bloc finally...
    emf.close();
  }

}

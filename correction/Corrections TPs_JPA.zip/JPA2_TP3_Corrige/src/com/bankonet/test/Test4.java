package com.bankonet.test;

import javax.persistence.*;
import com.bankonet.model.*;

/**
 * Teste la persistance de plusieurs classes, dont une "embedded".
 */
public class Test4 {

  public static void main(String[] args) {
    EntityManagerFactory emf = null;
    EntityManager em = null;
	EntityTransaction tx = null;
    try {
      emf = Persistence.createEntityManagerFactory("Employes");
      em = emf.createEntityManager();
      tx = em.getTransaction();
      tx.begin();
      // Cr�ation des 3 d�partements
      Departement dept1 = new Departement("Direction", "Nice");
      Departement dept2 = new Departement("Comptabilit�", "Nice");
      Departement dept3 = new Departement("Gestion personnel", "Nantes");
      em.persist(dept1);
      em.persist(dept2);
      em.persist(dept3);
      dept1.setLieu("Paris");
      // 2 clients avec leur adresse
      Adresse ad1 = new Adresse(36, "avenue Cyrnos", "Paris");
      Client client1 = new Client("Bibi", ad1);
      em.persist(client1);
      Adresse ad2 = new Adresse(50, "rue Victor Hugo", "Paris");
      Client client2 = new Client("Toto", ad2);
      em.persist(client2);
      // Cr�ation des 3 employ�s
      Employe emp1 = new Employe("Dupond");
      Employe emp2 = new Employe("Durand", dept2, emp1);
      Employe emp3 = new Employe("Legrand", dept1, null);
      em.persist(emp1);
      em.persist(emp2);
      em.persist(emp3);
      dept1.addEmploye(emp1);
      dept1.addEmploye(emp3);
      dept2.addEmploye(emp3);
      
      // creation de 3 projets
      Projet p1 = new Projet("Projet 1");
      Projet p2 = new Projet("Projet 2");
      Projet p3 = new Projet("Projet 3");
      em.persist(p1);
      em.persist(p2);
      em.persist(p3);
      
      // Association des projet aux employes
      emp1.addProjet(p1);
      emp1.addProjet(p2);
      emp2.addProjet(p1);
      emp3.addProjet(p3);
      emp3.addProjet(p2);
      
      // Creation des participation
      // Cr�ation de 2 projets
      Projet projet1 = new Projet("Qualit�");
      Projet projet2 = new Projet("Sport");
      projet1.ajouterParticipant(emp1, "Chef");
      projet1.ajouterParticipant(emp2, "Tr�sorier");
      projet2.ajouterParticipant(emp3, "Chef");
      em.persist(projet1);
      em.persist(projet2);
      
      
      tx.commit();
    }
    catch(Exception e) {
      // En "vrai" il faudrait affiner un peu plus...
      e.printStackTrace();
      if (tx != null) {
        tx.rollback();
      }
    }
    finally {
      if (em != null) {
        em.close();
      }
      if (emf != null) {
        emf.close();
      }
    }
  }
}


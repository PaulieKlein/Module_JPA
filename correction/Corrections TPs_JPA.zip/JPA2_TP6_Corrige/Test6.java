package jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 * Teste la r�cup�ration d'entit�s associ�es en analysant les requ�tes SQL
 * lanc�es par TopLink.
 * Lance une requ�te JQL pour �viter le probl�me des N+1 selects (join fetch).
 */
public class Test6 {

  public static void main(String[] args) {
    EntityManagerFactory emf = 
      Persistence.createEntityManagerFactory("Employes");
    EntityManager em = emf.createEntityManager();

    // R�cup�re tous les employ�s sans r�cup�rer les entit�s associ�s en m�me temps
    String texteQuery1 =
      "select e from Employe as e";
    Query query1 = em.createQuery(texteQuery1);
    List<Employe> listeEmployes = (List<Employe>)query1.getResultList();
    // Noms de tous les employ�s
    System.out.println("Liste des noms des employ�s :");
    for (Employe employe : listeEmployes) {
      System.out.println(employe.getNom());
    }
    // Noms de tous les employ�s, avec les projets auxquels ils participent
    System.out.println("Liste des projets des employ�s :");
    String nomEmployeCourant = "";
    for (Employe employe : listeEmployes) {
      String nomEmploye = employe.getNom();
      if (!nomEmployeCourant.equals(nomEmploye)) {
        // Passe � la ligne
        System.out.println();
        // Affiche le nom
        System.out.print(nomEmploye);
        nomEmployeCourant = nomEmploye;
      }
      // Affiche les noms des projets auxquels participe l'employ�
      List<Participation> participations = employe.getParticipations();
      for (Participation participation : participations) {
        System.out.print(" ; ");
        System.out.println(participation.getProjet().getNom());
      }
      System.out.println();
    }
    // Evite le probl�me des N+1 select (join fetch)
    // Vide le contexte de persistance (sinon, tout est d�j� charg�...).
    em.clear();
    String texteQuery2 =
      "select e from Employe as e join fetch e.participations";
    Query query2 = em.createQuery(texteQuery2);
    listeEmployes = (List<Employe>)query2.getResultList();
    System.out.println("Sans le probl�me des N+1 selects****");
    System.out.println("Liste des noms des employ�s :");
    for (Employe employe : listeEmployes) {
      System.out.println(employe.getNom());
    }
    // Noms de tous les employ�s, avec les projets auxquels ils participent
    System.out.println("Liste des projets des employ�s :");
    // Jointure externe pour avoir tous les employ�s, 
    // m�me ceux qui ne participent � aucun projet
    nomEmployeCourant = "";
    for (Employe employe : listeEmployes) {
      String nomEmploye = employe.getNom();
      if (!nomEmployeCourant.equals(nomEmploye)) {
        // Passe � la ligne
        System.out.println();
        // Affiche le nom
        System.out.print(nomEmploye);
        nomEmployeCourant = nomEmploye;
      }
      // Affiche les noms des projets auxquels participe l'employ�
      List<Participation> participations = employe.getParticipations();
      for (Participation participation : participations) {
        System.out.print(" ; ");
        System.out.println(participation.getProjet().getNom());
      }
      System.out.println();
    }
    emf.close();
  }

}

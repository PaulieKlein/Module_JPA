package com.bankonet.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.bankonet.model.*;

/**
 * 
 */
public class Test5 {

  public static void main(String[] args) {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("Employes");
    EntityManager em = emf.createEntityManager();
    // Noms de toutes les personnes (y compris les sous-classes)
    String texteQuery1 =
      "select p.nom from Personne as p";
    Query query1 = em.createQuery(texteQuery1);
    List<String> listeNoms = (List<String>)query1.getResultList();
    System.out.println("Noms des personnes");
    for (String nom : listeNoms) {
      System.out.println(nom);
    }
    String texteQuery1Bis =
      "select p.nom from Personne as p where type(p) = Client";
    Query query1Bis = em.createQuery(texteQuery1Bis);
    List<String> listeNomsBis = (List<String>)query1Bis.getResultList();
    System.out.println("Noms des clients");
    for (String nom : listeNomsBis) {
      System.out.println(nom);
    }
    // Noms de tous les employ�s, avec les projets auxquels ils participent
    System.out.println("Liste des projets :");
    // Jointure externe pour avoir tous les employ�s, m�me ceux 
    // qui ne participent � aucun projet
    String texteQuery2 =
      "select e.nom, particip.projet.nom, particip.fonction " +
      "from Employe as e left outer join e.participations as particip " +
      "order by e.nom";
    Query query2 = em.createQuery(texteQuery2);
    List<Object[]> listeProjets = (List<Object[]>)query2.getResultList();
    // Suppose que 2 employ�s n'ont pas le m�me nom (sinon, utiliser plut�t l'id).
    String nomEmployeCourant = "";
    for (Object[] infos : listeProjets) {
      String nomEmploye = (String)infos[0];
      if (!nomEmployeCourant.equals(nomEmploye)) {
        // Passe � la ligne
        System.out.println();
        // Affiche le nom
        System.out.print(nomEmploye);
        nomEmployeCourant = nomEmploye;
      }
      // Affiche le nom du projet s'il n'est pas null
      String nomProjet = (String)infos[1];
      if (nomProjet != null) {
        System.out.print(", " + nomProjet);
      }
      
   // Affiche la fonction de la personne sans le projet si elle n'est pas null
      String fonction = (String)infos[2];
      if (fonction != null) {
        System.out.print(", fonction : " + fonction);
      }
    }
    // En exercice : ajouter catch et finally
    emf.close();
  }

}

package com.bankonet.model;


public class Participation {

}

package com.bankonet.test;

import java.util.List;
import java.util.concurrent.Callable;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.LockModeType;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.bankonet.model.*;

public class Test9 {

  /**
   * Test des entit�s versionn�es et de la m�thode lock.
   * @param args
   * @throws InterruptedException 
   */
  public static void main(String[] args) throws InterruptedException {
    final EntityManagerFactory emf = 
      Persistence.createEntityManagerFactory("Employes");
    EntityManager em = emf.createEntityManager();
    EntityTransaction t = em.getTransaction();
    t.begin();
    // R�cup�re un d�partement
    Query q = em.createQuery("select d from Departement d");
    List<Departement> liste = q.getResultList();
    Departement d = liste.get(0);
    System.out.println("**Au d�but : " + d);
    // Sans ce lock, il faut que cette transaction modifie d pour
    // qu'une exception soit lev�e.
    // Le mode WRITE incr�menterait le num�ro de version
    em.lock(d, LockModeType.READ);
    // V�rification du num�ro de version
    System.out.println("**Apr�s le lock : " + d);
    // Affichage du num�ro de version du d�partement
    System.out.println(d.getVersion());
    // Lancer ici un autre thread qui utilise un autre entityManager
    // pour modifier le nom du d�partement.
    Runnable tache = new Runnable() {
      /**
       * T�che qui modifie le nom du d�partement bloqu� et qui renvoie
       * la valeur du num�ro de version lu au d�but (� la fin ?).
       */
      @Override
      public void run() {
        try {
          Thread.sleep(2000);
        } catch (InterruptedException e) {
          e.printStackTrace();
        }
        EntityManager em = emf.createEntityManager();
        EntityTransaction t = em.getTransaction();
        t.begin();
        Query q = em.createQuery("select d from Departement d");
        List<Departement> liste = q.getResultList();
        Departement d = liste.get(0);
        d.setNom("Truc33");
        t.commit();
        System.out.println("**Dans l'autre thread : " + d);
        em.close();
      }
    };
    Thread thread = new Thread(tache);
    thread.start();
    // Attend pour permettre une modification concurrente
    System.out.println("Dors....");
    Thread.sleep(10000);
    // Modification du d�partement
    // Il faut cette ligne pour provoquer une exception s'il n'y a pas eu de lock
//    d.setNom("Direction g�n�rale3");
    System.out.println("**Apr�s la modification par le thread principal : " + d);

    // Provoquera une OptimisticLockException � cause de la modification 
    // effectu�e par le thread lanc� en parall�le.
    t.commit();
    System.out.println("Apr�s le commit du thread principal : " + d);

  }

}

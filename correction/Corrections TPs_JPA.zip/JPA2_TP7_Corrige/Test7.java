package com.bankonet.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.EntityTransaction;
import com.bankonet.model.*;

/**
 * Teste des comportements avec ou sans transaction.
 */
public class Test7 {

  public static void main(String[] args) {
    EntityManagerFactory emf = 
      Persistence.createEntityManagerFactory("Employes");
    EntityManager em = emf.createEntityManager();

    // Cr�e un nouveau d�partement et le rend persistant, sans transaction
    Departement dept1 = new Departement("Direction", "Nice");
    System.out.println("***" + em.contains(dept1));
    // On remarque que TopLink d�marre automatiquement une transaction
    // mais aucune modification n'est effectu�e dans la base
    // pendant cette transaction ; seule une s�quence est incr�ment�e.
    em.persist(dept1);
    dept1.setLieu("Tourcoing");
    System.out.println("***" + em.contains(dept1));

    // Ouvre une transaction. Est-ce que le contexte de persistance
    // va enregistrer les modifs pr�c�dentes ?
    // R�ponse : oui.
    EntityTransaction tx = em.getTransaction();
    tx.begin();
    tx.commit();

    // Que se passe-t-il si on fait un flush explicite 
    // mais pas � l'int�rieur d'une transaction ?
    // R�ponse : impossible de faire un flush en dehors d'une transaction ;
    // une exception TransactionRequiredException est lev�e.
    dept1.setLieu("Roubaix");
    em.flush();

//     em.refresh(dept1); // provoque une exception
    System.out.println("***" + dept1.getLieu());
    em.close();
    emf.close();
  }

}

package com.bankonet.model;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.GeneratedValue;

import javax.persistence.Id;

/** 
 * Un employ� de l'entreprise.
 */
@Entity

public class Employe extends Personne {
	@Id
	@GeneratedValue
	private  int id;
	
  private BigDecimal salaire;
  @ManyToOne
  private Employe superieur;
  @ManyToOne
  private Departement departement;
	
  public Employe() {
  }
	
  public Employe(String nom) {
    super(nom);
  }

  public Employe(String nom, Departement departement, Employe superieur) {
   super(nom);
    departement.addEmploye(this);
    this.superieur = superieur;
  }

  public BigDecimal getSalaire() {
    return salaire;
  }

  public void setSalaire(BigDecimal salaire) {
    this.salaire = salaire;
  }

  public Employe getSuperieur() {
    return superieur;
  }

  public void setSuperieur(Employe employe) {
    this.superieur = employe;
  }

  public Departement getDepartement() {
    return departement;
  }

  public void setDepartement(Departement departement) {
    this.departement = departement;
  }
}

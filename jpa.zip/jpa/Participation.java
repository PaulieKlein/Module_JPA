package jpa;


public class Participation {

}
